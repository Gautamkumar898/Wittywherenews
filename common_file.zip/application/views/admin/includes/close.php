<script>
	window.close();                                              
</script>


